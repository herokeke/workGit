CREATE VIEW SERVICEREQUEST_DEP AS select a.basecreatordep,a.basestatus,a.basecreatedate,a.relation_system,
case when (case
                 when base.BASEACCEPTDATE = '0' then
                   case
                     when base.BASEACCEPTOUTTIME = '0' then
                       0
                     else
                       DATE_TO_SEC( TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS'))
                   end
                 else
                  to_number(base.BASEACCEPTDATE)
               end) -
               decode(base.BASEACCEPTOUTTIME,null,0,TO_NUMBER(base.BASEACCEPTOUTTIME))>0 then '是'
              else '否'
              end as acceptTimeout,
              base.BASEFINISHDATE,--处理时间
              base.BASEDEALOUTTIME,--处理时限
              case when (case
                 when base.BASEFINISHDATE = '0' then
                   case
                     when base.BASEDEALOUTTIME = '0' then
                       0
                     else
                       DATE_TO_SEC( TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS'))
                   end
                 else
                  to_number(base.BASEFINISHDATE)
               end) -
               decode(base.BASEDEALOUTTIME,null,0,TO_NUMBER(base.BASEDEALOUTTIME))>0 then '是'
              else '否'
              end as dealTimeout,
              (case when a.isvip is null then '否' else '是' end) as isvip ,
              (case when a.satisfaction_level='非常满意' or a.satisfaction_level='满意' then '是' else '否' end) as satisfaction,
              a.cdbteamname,a.cdbdealteamname,a.baseid
 from bs_t_bpp_baseinfor base , bs_f_cdb_servicerequest a where base.baseid=a.baseid and base.baseschema='CDB_SERVICEREQUEST'
/
