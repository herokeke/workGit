CREATE FUNCTION          "SEC_TO_DATE"  (xin in number)
    return date is
 out_para date;
 begin
 select (xin+28800)/3600/24+to_date('1970-01-01 00:00:00','YYYY-MM-DD HH24:MI:SS') into out_para from dual;
 return out_para;
 end;

/
