CREATE procedure p_get_menu_byparentmenu(v_roleid in varchar2,pmenuid in varchar2,pmenuname in varchar2,rootnodename in varchar2) as
   cursor c_mune is
   select mu.pid,mu.nodename from bs_t_sm_rolemenutree rm,bs_t_sm_menutree  mu
    where rm.roleid=v_roleid and rm.menuid = mu.pid  and mu.parentid=pmenuid;

  c_nodeid varchar2(200);
  c_nodename varchar2(200);
  n_count number;
  c_res varchar2(200);
  c_cc number;
begin
n_count:=0;
c_cc:=0;
 select count(*) into c_cc from bs_t_sm_rolemenutree rm,bs_t_sm_menutree  mu
    where rm.roleid=v_roleid and rm.menuid = mu.pid  and mu.parentid=pmenuid;
  if c_cc=0 then
     insert into bs_t_wf_role_tmp values(pmenuid,pmenuname,v_roleid,rootnodename);
        commit;
  end if;

 open c_mune;
  loop
      fetch c_mune into c_nodeid,c_nodename;
      exit when c_mune%notfound;

      --如果大于0说明有子节点
        select count(mu.pid)
         into n_count
         from bs_t_sm_rolemenutree rm, bs_t_sm_menutree mu
        where rm.roleid = v_roleid
     and rm.menuid = mu.pid  and mu.parentid=c_nodeid;
      --如果大于0说明有子节点,小于0说明没有子节点
      if  n_count >0 then
         -- p_res:=p_res||'->'||c_nodename;
          p_get_menu_byparentmenu(v_roleid,c_nodeid,c_nodename,rootnodename);
        else
        c_res:=c_nodename;
        insert into bs_t_wf_role_tmp values(c_nodeid,c_nodename,v_roleid,rootnodename);
        commit;
     end if ;

   end loop;

end p_get_menu_byparentmenu;

/
