CREATE procedure dynamic_pivot(p_cursor in out sys_refcursor)
as
    sql_query varchar2(1000) := 'select u_name ';

    begin
        for x in (select dt from tmp_q order by 1)
        loop
            sql_query := sql_query ||
              ' , sum(decode(dt,x,nvl(解决率,0),0)) 解决率'  ;

                dbms_output.put_line(sql_query);
        end loop;

        sql_query := sql_query || ' from tmp_q group by u_name';

        open p_cursor for sql_query;
    end;
/
