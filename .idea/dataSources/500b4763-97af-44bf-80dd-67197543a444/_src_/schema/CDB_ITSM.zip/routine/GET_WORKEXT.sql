CREATE function get_workExt(datetime date) return varchar2 is
/*
   @datetime  指定日志char类型YYYY-MM-DD
   @num  指定工作日
   描述：查询出 指定日期减去指定工作日后的日期。系统节假日表的优先级大于正常周六日。
*/
    output  varchar2(20);
    m number :=0;
    parm number :=0;
    dav number :=2;
  begin
    LOOP
         begin
           select count(holidayflag) into parm  from bs_t_sm_holiday where dateinfo=to_char(datetime+m,'yyyy-mm-dd');
               if parm<>0then--有记录
                     begin
                       select holidayflag into dav  from bs_t_sm_holiday where dateinfo=to_char(datetime+m,'yyyy-mm-dd');
                     end;
                end if;
               if    to_char(datetime+m,'D')not in(1,7) then--工作日
                        if dav=0 then --节假日
                           m := m+1;
                        else
                           exit;
                        end if;
                 elsif    to_char(datetime+m,'D') in (1,7) then--节假日
                         if dav=1 then --非节假日
                           exit;
                         else
                           m := m+1;
                        end if;
               end if;
               parm:=0;
               dav:=2;
           end;
       end LOOP;
         output := to_char(datetime+m,'yyyy-mm-dd');
    return output;
end get_workExt;
/
