CREATE function          get_users_bygroupId(gid in varchar2) return varchar2 is
  --根据组id获取到组人员信息
  cursor c_users is select udep.loginname,u.fullname from bs_t_sm_userdep udep left join bs_t_sm_user u on udep.userid= u.pid
 where udep.depid =(select dep.pid from bs_t_sm_dep dep where dep.pid=gid);
  c_loginname varchar2(200);
  c_fullname varchar2(200);
  res varchar2 (4000);
begin
  res:='';
 open c_users;
  loop
      fetch c_users into c_loginname,c_fullname;
      exit when c_users%notfound;
           if res is null then
            res:=c_fullname||' '||c_loginname;
            else
             res:=res||','||c_fullname||' '||c_loginname;
            end if ;
   end loop;
   close c_users;
  return res;
end get_users_bygroupId;

/
