CREATE FUNCTION          getfulldepid (intpid IN varchar)
RETURN varchar
AS
ret varchar(2000);
BEGIN
select  REPLACE(('.'||wm_concat(t.org_code)),',','.') into ret from (
select a.org_code,a.dic_comment from  bs_f_wf_eiidep a start with  a.org_code =intpid

connect by prior a.parent_org_code=a.org_code  order by a.dic_comment,a.org_code) t;

  return ret;
end ;

/
