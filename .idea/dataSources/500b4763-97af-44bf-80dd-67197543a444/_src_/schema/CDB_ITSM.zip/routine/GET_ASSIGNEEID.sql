CREATE FUNCTION          "GET_ASSIGNEEID" (baseidP NVARCHAR2)
--根据工单baseid获得工单的当前处理人,针对非关闭的单子
 return  nvarchar2
as
 ret nvarchar2(2000);

begin
  select t.assignee into ret from BS_T_WF_CURRENTTASK t where t.baseid = baseidP;
return ret;
end;

/
