CREATE function get_sysdateSecond
 return number is
  output number;
begin
  select trunc(to_number(sysdate - to_date('1970-01-01 08:00:00','YYYY-MM-DD HH24:MI:SS'))*86400,0)
         into output from dual;
  return output;
end get_sysdateSecond;
/
