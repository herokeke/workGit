CREATE FUNCTION          "DATE_TO_SEC" (strDate IN CHAR)
--将日期型转换为整型秒
        RETURN INT
AS
        ret NUMBER;
        iDate DATE;
        tDate varchar2(30);
BEGIN

        if(length(strDate))>=18 then
         tDate:='YYYY-MM-DD HH24:MI:SS';
        elsif (length(strDate))>7 then
         tDate:='YYYY-MM-DD';
        else
         tDate:='YYYY-MM';
        end if;
        iDate:=TO_DATE(strDate,tDate);
        ret := (iDate-TO_DATE('1970-1-1 8:0:0','YYYY-MM-DD HH24:MI:SS'))*(24*60*60);
    RETURN ret;
END ;

/
