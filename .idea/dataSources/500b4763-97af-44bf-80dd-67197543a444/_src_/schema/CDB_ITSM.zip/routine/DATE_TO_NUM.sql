CREATE function          DATE_TO_NUM(param in varchar2)
 return number is
  output number;
begin
  select trunc(to_number(to_date(param,'YYYY-MM-DD HH24:MI:SS')-to_date('1970-01-01 08:00:00','YYYY-MM-DD HH24:MI:SS'))*86400,0)
         into output from dual;
  return output;
end DATE_TO_NUM;

/
