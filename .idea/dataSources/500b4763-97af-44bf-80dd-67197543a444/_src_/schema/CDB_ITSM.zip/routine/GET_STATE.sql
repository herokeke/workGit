CREATE FUNCTION GET_State(setbaseid VARCHAR2)
 return  varchar2
as
 output nvarchar2(2000);
begin
SELECT phaseno INTO output from (select (case phaseno
                    when 'dp_24' then
                     '实施中'
                    when 'dp_23' then
                     '评审中'
                    when 'dp_16' then
                     '审批中'
                  end) phaseno 
             from (select phaseno, eddate,baseid
                     from bs_t_wf_dealprocess p
                    where baseschema = 'CDB_RELEASE'
                      and p.baseid = setbaseid
                    order by eddate desc)
            where rownum = 1);
return output;
end GET_State;

/
