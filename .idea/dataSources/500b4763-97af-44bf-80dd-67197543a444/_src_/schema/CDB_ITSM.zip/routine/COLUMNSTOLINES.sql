CREATE FUNCTION  ColumnsToLines (dateStr1 IN NVARCHAR2,dateStr2 IN NVARCHAR2)
--将
RETURN nvarchar2
AS
 ret nvarchar2(4000);
 i number:=0;
 str_len number:=0;
 restr nvarchar2(4000):='';

BEGIN
select en_concat(to_char(add_months(to_date(dateStr1,'YYYY-MM-DD HH24:MI:SS'),+(rownum-1)),'yyyy-mm')) dt into ret from dual connect by rownum <= 12-to_number(to_char(to_date(dateStr1, 'YYYY-MM-DD HH24:MI:SS'),'mm'))+ to_number(to_char(to_date(dateStr2, 'YYYY-MM-DD HH24:MI:SS'),'mm'))+
(to_number(to_char(to_date(dateStr2,'YYYY-MM-DD HH24:MI:SS'),'yyyy'))-to_number(to_char(to_date(dateStr1,'YYYY-MM-DD HH24:MI:SS'),'yyyy')))*12;
str_len:=Get_StrArrayLength(ret,';');
for  i in 0..str_len loop
  if i=0 then
    restr:=(restr||Get_StrArrayStrOfIndex(ret,';',i));
    dbms_output.put_line(restr||',');
    else
  restr:=(restr||','||Get_StrArrayStrOfIndex(ret,';',i));
  dbms_output.put_line(restr||',');
  end if;
end loop;
--restr:=(restr||' from dual');
dbms_output.put_line(restr||',');
RETURN restr;
END ColumnsToLines;
/
