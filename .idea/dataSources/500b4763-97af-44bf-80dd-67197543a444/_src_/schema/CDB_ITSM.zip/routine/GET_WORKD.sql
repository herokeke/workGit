CREATE function get_workD(datetime date,num in number) return varchar2 is
/*
   @datetime  指定日志char类型YYYY-MM-DD
   @num  指定工作日
   描述：查询出 指定日期减去指定工作日后的日期。系统节假日表的优先级大于正常周六日。
*/
    output  varchar2(20);
    i number :=1;
    m number :=1;
    nums number := num;
    parm number :=0;
    dav number :=2;
  begin
    while i <= num LOOP
         begin
           select count(holidayflag) into parm  from bs_t_sm_holiday where dateinfo=to_char(datetime-m,'yyyy-mm-dd');
               if parm<>0then--有记录
                     begin
                       select holidayflag into dav  from bs_t_sm_holiday where dateinfo=to_char(datetime-m,'yyyy-mm-dd');
                     end;
                end if;
               if    to_char(datetime-m,'D')not in(1,7) then--工作日
                     begin
                        if dav=0 then
                          nums := nums+1;
                        else
                           i:= i + 1;
                        end if;
                     end;
                 elsif    to_char(datetime-m,'D') in (1,7) then--节假日
                     begin
                         if dav=1then
                            i:= i + 1;
                         else
                           nums := nums+1;
                        end if;
                     end;
               end if;
               m:= m + 1;
               parm:=0;
               dav:=2;
           end;
        end LOOP;
         output := to_char(datetime-nums,'yyyy-mm-dd');
    return output;
end get_workD;
/
