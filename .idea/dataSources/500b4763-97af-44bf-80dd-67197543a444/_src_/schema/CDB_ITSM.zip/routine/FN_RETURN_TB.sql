CREATE function fn_return_tb

return type_tb

is

o_tb type_tb := type_tb();

i number := 0;

begin

  for v_rec in (select 1 as idx, 'Andy' as user_name from dual

  union select 2, 'Jack' from dual

  union select 3, 'Paul' from dual) loop

    o_tb.extend;

    i := i + 1;

    o_tb(i) := type_rec (v_rec.idx, v_rec.user_name);

  end loop;

  return o_tb;

end fn_return_tb;
/
