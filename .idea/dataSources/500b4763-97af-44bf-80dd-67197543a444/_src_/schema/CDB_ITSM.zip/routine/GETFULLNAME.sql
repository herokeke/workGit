CREATE FUNCTION          getfullname (intpid IN varchar)
RETURN varchar
AS
ret varchar(2000);
BEGIN
select REPLACE(REPLACE((en_concat(t.dic_mem_name)),';','.'),'国家开发银行','cdb') into ret from (
select a.org_code,a.dic_mem_name from  eiiorg a start with  a.org_code =intpid
connect by prior a.parent_org_code=a.org_code  order by length(a.org_code) ,a.dic_mem_code,a.dic_comment) t;
return ret;
end ;

/
