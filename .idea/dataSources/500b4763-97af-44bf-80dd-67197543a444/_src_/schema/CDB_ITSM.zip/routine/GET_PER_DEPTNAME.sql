CREATE FUNCTION          "GET_PER_DEPTNAME" (loginnameP NVARCHAR2)
--根据人员的登陆名查看人员所在处室
 return  nvarchar2
as
 ret nvarchar2(2000);
begin
  select substr(z.depfullname,instr(z.depfullname,'.',-1,1)+1) into ret from bs_t_sm_dep z where z.pid =(select depid from bs_t_sm_user y where y.loginname = loginnameP);
return ret;
end;

/
