CREATE function          get_menu_byrole(v_roleid in varchar2) return  varchar2 is


  --获取角色有权限的一级菜单第
   cursor c_role is select mu.pid,mu.nodename from bs_t_sm_rolemenutree rm,bs_t_sm_menutree  mu
    where rm.roleid=v_roleid and rm.menuid = mu.pid  and mu.nodetype='0';
   c_roleid varchar2(200);
   c_nodeid varchar2(200);
  c_nodename varchar2(200);
  res varchar2(2000);
  --c_menu t_rolemenu;
begin
  delete from bs_t_wf_role_tmp;
  commit;
 open c_role;
  loop
      fetch c_role into c_nodeid,c_nodename;
           exit when c_role%notfound;
           if res is null then
           res:=c_nodename;
         /*  else
              res:=res||'&&'||c_nodename;*/
             end if ;
             p_get_menu_byparentmenu(v_roleid,c_nodeid,c_nodename);

   end loop;
   close c_role;
   return res;
end get_menu_byrole;

/
