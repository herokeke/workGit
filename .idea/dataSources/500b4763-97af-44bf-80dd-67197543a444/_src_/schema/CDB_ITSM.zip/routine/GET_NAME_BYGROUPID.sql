CREATE function          get_name_bygroupid(gid in varchar2) return varchar2 is
  --根据组id获取到组名
   res varchar2 (4000);
begin
 select dep.depname into res from bs_t_sm_dep dep where dep.pid = gid;
  return res;
end get_name_bygroupid;

/
