CREATE FUNCTION          "GET_SOLVER" (baseidP NVARCHAR2)
--根据工单baseid获得工单的解决人,针对已经关闭的单子(点击了处理完成)
 return  nvarchar2
as
 ret nvarchar2(2000);

begin
  select (case when closeSheet > 0 then (select currentuser from (select q.currentuser from bs_t_wf_record q where baseid = baseidP and  q.dealaction = '处理完成' order by q.dealtime desc) t where rownum = 1)
              when closeSheet=0 then (select x.basecreatorfullname from bs_t_bpp_baseinfor x where x.baseid= baseidP)
               end) into ret  from (
               select  count(*) closeSheet   from bs_t_wf_record q  where baseid = baseidP and  q.dealaction = '处理完成'
               );
return ret;
end;

/
