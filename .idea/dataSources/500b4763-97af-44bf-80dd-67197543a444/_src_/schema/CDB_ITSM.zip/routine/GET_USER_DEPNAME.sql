CREATE function          get_user_depname(dname  in varchar2) return varchar2 is
  cursor c_mem is select loginname,fullname  from (
  select instr(su.groupname,dname) aa ,su.loginname,su.fullname from bs_t_sm_user su )  where aa>0;
  c_loginname varchar2(200);
  c_fullname varchar2(200);
  res varchar2 (2000);
begin
  res:='';
 open c_mem;
  loop
      fetch c_mem into c_loginname,c_fullname;
      exit when c_mem%notfound;
           if res is null then
            res:=c_fullname||' '||c_loginname;
            else
             res:=res||','||c_fullname||' '||c_loginname;
            end if ;
   end loop;
   close c_mem;
  return res;
end get_user_depname;

/
