CREATE procedure sql_test
  (  out_return out sys_refcursor)
   is begin
     open out_return for 'select  pid from bs_t_sm_user where rownum<10';
     end;
/
