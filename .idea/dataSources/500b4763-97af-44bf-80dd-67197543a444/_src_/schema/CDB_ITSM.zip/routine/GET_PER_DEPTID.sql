CREATE FUNCTION          "GET_PER_DEPTID" (loginnameP NVARCHAR2)
--根据人员的登陆名查看人员所在处室
 return  nvarchar2
as
 ret nvarchar2(2000);
begin
  select z.pid into ret from bs_t_sm_dep z where z.pid =(select depid from bs_t_sm_user y where y.loginname = loginnameP);
return ret;
end;

/
