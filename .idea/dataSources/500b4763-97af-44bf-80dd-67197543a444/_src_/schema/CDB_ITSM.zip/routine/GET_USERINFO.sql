CREATE function          get_userinfo (uid in varchar2,c_v in varchar2) return varchar2 is
  c_groupname varchar2(2000);
  c_depname varchar2(200);
  n_num number;
  c_groupname1 varchar2(2000);
  v_tmp varchar2(200);
  v_td varchar2(200);
  res varchar2(2000);
  --c_v为1返回团队名称 ，c_v为2则返回所属岗信息
  begin
  res:='';
  n_num:=0;
  --获取人员部门及所属组信息
  select u.groupname,u.depname into c_groupname,c_depname  from bs_t_sm_user u  where u.pid = uid  ;
  --对所属组的值按分号进行拆分，如果没有分号有两种情况 1.只属于一个组;2.属于多个组，但已经拆分到了最后一个
  --对属于多个组情况进行处理
  while instr(c_groupname,',') <> 0 loop
    n_num:=n_num+1;
    --取到当前值
    c_groupname1:=substr(c_groupname,1,instr(c_groupname,',')-1);
    if c_groupname1<>c_depname then
      --判断是否为团队
      select dep.deptype into v_tmp from bs_t_sm_dep dep where dep.depname =  c_groupname1 and
      dep.parentid in (select pid from bs_t_sm_dep where depname =c_depname);
         if v_tmp= 4 then
           v_td:=c_groupname1;
           else
             --拼接组的数据
             if res is null then
               res:= c_groupname1;
               else
                res:=res||','||c_groupname1;
             end if;
         end if;
     end if;
    --截取后边的值
    c_groupname:=substr(c_groupname,instr(c_groupname,',')+length(','),length(c_groupname));
  end loop;
  --对没有分号有两种情况 1.只属于一个组;2.属于多个组，但已经拆分到了最后一个;进行处理
  if c_groupname<>c_depname and c_groupname<>'信息科技局'then
    --如果组的值不是部门，则判断是否为团队
    select dep.deptype into v_tmp from bs_t_sm_dep dep where dep.depname =  c_groupname and
      dep.parentid in (select pid from bs_t_sm_dep where depname =c_depname);
         if v_tmp= 4 then
           v_td:=c_groupname;
          else
            --如果不是团队，且res是空则说明用户只有一个所属组，对res进行赋值
             if res is null then
              res:=c_groupname;
              else
              --  res不是空则说明c_groupname是拆分后的值，对res进行追加赋值
               res:=res||','||c_groupname;
    end if;
          end if;
  end if;
  --c_v为1返回团队名称
  if  c_v ='1' then
    return v_td;
  --c_v为2返回所属岗位信息
   elsif  c_v ='2' then
     return res;
   end if;

end get_userinfo;

/
