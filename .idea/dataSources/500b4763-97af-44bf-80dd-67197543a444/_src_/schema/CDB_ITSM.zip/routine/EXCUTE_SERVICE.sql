CREATE procedure excute_service(parm1 varchar2,
                                          parm2 varchar2,
                                          parm3 varchar2,
                                          parm4 varchar2,
                                          parm5 varchar2,
                                          parm6 varchar2,ptype varchar2) AS
 
begin
if ptype=1 then
	update bs_f_cdb_servicerequest
     set isRequireServiceImpl = parm1,
         requireDealTime      = parm2,
         basedealouttime      = parm3,
         DealTimeLimit        = parm4,
         appRequireDealTime   = parm5
   where basesn = parm6;
end if;
if ptype=2 then
    update bs_t_bpp_baseinfor
     set basedealouttime = parm3
   where basesn = parm6;
end if;
if ptype=3 then
	update bs_f_cdb_servicerequest
     set isRequireServiceImpl = parm1,
         requireDealTime      = parm2,
         appRequireDealTime   = parm5
   where basesn = parm6;
end if;
  commit;
end excute_service;
/
