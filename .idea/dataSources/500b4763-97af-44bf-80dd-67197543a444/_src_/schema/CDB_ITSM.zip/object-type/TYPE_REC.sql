CREATE type type_rec is object (idx integer, user_name varchar2(50))
/
