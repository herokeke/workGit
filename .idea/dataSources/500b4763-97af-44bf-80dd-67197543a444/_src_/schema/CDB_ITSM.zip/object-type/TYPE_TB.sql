CREATE type type_tb is table of type_rec
/
