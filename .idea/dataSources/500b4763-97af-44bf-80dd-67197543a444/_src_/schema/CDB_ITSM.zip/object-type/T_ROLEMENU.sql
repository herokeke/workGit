CREATE TYPE          "T_ROLEMENU"                                                                                   as object
(
  -- Author  : C0141308
  -- Created : 2015/4/27 23:25:08
  -- Purpose :

  -- Attributes
  FULLNODENAME varchar2(200)

  -- Member functions and procedures
 -- member procedure <ProcedureName>(<Parameter> <Datatype>)
)

/
