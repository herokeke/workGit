CREATE TYPE Typ_o_Xml_Secondary AS OBJECT
(
  s_Id   NUMBER,
  s_Name VARCHAR2(10),
  p_Id   NUMBER
)
/
