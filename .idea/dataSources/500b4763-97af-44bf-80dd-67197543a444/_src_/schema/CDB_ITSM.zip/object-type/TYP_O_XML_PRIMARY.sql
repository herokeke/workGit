CREATE TYPE Typ_o_Xml_Primary AS OBJECT
(
  p_Id   NUMBER,
  p_Name VARCHAR2(20),
  s_Data Typ_Xml_Secondary
)
/
