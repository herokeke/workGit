CREATE package body rpt is
  -----------------------------------用于打印日志的存储过程--------------------------------------------------------------------------
  procedure print(printclob clob,
                  printdesc varchar2 := '---------------',
                  isprint   varchar2 := 'true') as
  begin
    if isprint = 'true' then
      begin
        -- 打印提示信息
        dbms_output.put_line(printdesc);
        -- 循环打印字符串,一行最大打印255个字符
        for i in 1 .. length(printclob) / 255 + 1 LOOP
          dbms_output.put_line(substrb(to_char(printclob),
                                       1 + 255 * (i - 1),
                                       255));
        -- 打印换行标识符（当打印出来的sql由于换行执行报错时，用UltraEdit的替换功能，把^p/*|*/^p替换为空即可正确执行）
          dbms_output.put_line('/*|*/');
        end loop;
      end;
    end if;
  exception
    when no_data_found then
      dbms_output.put_line('err:没有查到数据!');
    when others then
      print('err:' || substr(sqlerrm, 1, 250));
  end;
  ----------------------------------将一列转换成指定符号连接的字符串------------------------------------------------------------------
  function get_column(str_sql varchar2, compart varchar2 := ',') return clob is
    type rawcurtyp is ref cursor;
    raw_cv   rawcurtyp;
    temp_str clob;
    output   clob;
    err_msg  varchar2(100);
  begin
    open raw_cv for('select * from (' || str_sql || ') where rownum<=500');
    loop
      if output is null then
        fetch raw_cv
          into output;
        exit when raw_cv%notfound;
      else
        fetch raw_cv
          into temp_str;
        exit when raw_cv%notfound;
        output := output || compart || temp_str;
      end if;
    end loop;
    close raw_cv;
    if output is null then
      output := ' ';
    end if;
    print('成功执行!');
    return output;

  exception
    when no_data_found then
      print('错误(返回空格字符):没有查到数据!');
      return ' ';
    when others then
      err_msg := substr(sqlerrm, 1, 100);
      print('错误(返回空格字符):' || err_msg);
      return ' ';
  end get_column;

  ----------------------------------13位毫秒值转换成datetime----------------------------------------------------------------------
  function get_datetime(millisecond number) return date is
    output  date;
    err_msg varchar2(100);
  begin
    output := (trunc(sysdate, 'hh') +
              (millisecond - (get_millisecond(trunc(sysdate, 'hh')))) /
              86400000);
    print('成功执行!');
    return output;
  exception
    when no_data_found then
      print('错误(返回null):没有查到数据!');
      return null;
    when others then
      err_msg := substr(sqlerrm, 1, 100);
      print('错误(返回null):' || err_msg);
      return null;
  end get_datetime;
  ----------------------------------datetime转换成13位毫秒值----------------------------------------------------------------------
  function get_millisecond(datetime date) return number is
    output  number(13);
    err_msg varchar2(100);
  begin
    output := (datetime -
              to_date('1970-01-01 08:00:00', 'yyyy-mm-dd hh24:mi:ss')) *
              86400000;
    print('成功执行!');
    return output;
  exception
    when no_data_found then
      print('错误(返回null):没有查到数据!');
      return null;
    when others then
      err_msg := substr(sqlerrm, 1, 100);
      print('错误(返回null):' || err_msg);
      return null;
  end get_millisecond;
  ----------------------------------返回特定的【and res_id in (a,b,c)】格式----------------------------------------------------------------------------
  function get_expression(field_name  varchar2,
                          field_value varchar2,
                          compart     varchar2 := '''',
                          field_jion  varchar2 := 'and') return varchar2 is
    output  varchar2(8000);
    err_msg varchar2(100);
  begin
    output := ' ';
    -- 字段名称是否是null值
    if field_name is null or lower(field_name) = 'null' then
      return output;
    end if;

    select case
             when field_value is null then
              ' '
             when lower(field_value) = 'null' then
              ' '
             else
              ' ' || field_jion || ' ' || field_name || ' in (' || compart ||
              replace(field_value, ',', compart || ',' || compart) ||
              compart || ') '
           end fields
      into output
      from dual;
    print('成功执行!');
    return output;

  exception
    when no_data_found then
      print('错误(返回空格字符):没有查到数据!');
      return ' ';
    when others then
      err_msg := substr(sqlerrm, 1, 100);
      print('错误(返回空格字符):' || err_msg);
      return ' ';
  end get_expression;
  --------------------------------交叉表---------------------------------------------------------------------------------------------
  function get_crosstab(data_table_name varchar2, -- 1  数据表_表名
                        data_time_id    varchar2, -- 2  数据表_时间列
                        data_value      varchar2, -- 3  数据表_数据列
                        data_start_time varchar2, -- 4  数据表_开始时间
                        data_end_time   varchar2, -- 5  数据表_结束时间
                        data_dim_row    varchar2, -- 6  数据表_行维度(注意和行维度对应,参数8)
                        data_dim_col    varchar2, -- 7  数据表_列维度(注意和列维度对应,参数11)
                        row_table_name  varchar2, -- 8  行_维度数据表_表名(注意和行维度对应,参数6)
                        row_id          varchar2, -- 9  行_维度数据表_ID列
                        row_name        varchar2, -- 10 行_维度数据表_名称列
                        col_table_name  varchar2, -- 11 列_维度数据表_表名(注意和行维度对应,参数7)
                        col_id          varchar2, -- 12 列_维度数据表_ID列
                        col_name        varchar2, -- 13 列_维度数据表_名称列
                        row_topn        numeric := 10,  -- 14 行_topN
                        col_topn        numeric := 10,  -- 15 列_topN
                        data_sql_part   varchar2 := '', -- 16 数据表_条件表达式
                        row_sql_part    varchar2 := '', -- 17 行_维度数据表_条件表达式
                        col_sql_part    varchar2 := '', -- 18 列_维度数据表_条件表达式
                        row_order       varchar2 := 'desc', -- 19 行_维度数据表_排序
                        col_order       varchar2 := 'desc', -- 20 列_维度数据表_排序
                        is_have_otheres varchar2 := 'false' -- 21 合计行的行号是否换成'合计'
                        ) return clob is
    -- 返回的交叉表(两个维度)的sql语句,适用于星形结构的数据表
    str_sql          clob;
    sql_p0           clob;
    sql_p1           clob;
    sql_p2           clob;
    sql_p3           clob;
    sql_p4           clob;
    sql_p5           clob;
    sql_p6           clob;
    sql_col          varchar2(4000); -- 查询列的排名
    sql_isfirst      varchar2(10);   -- 判断是否是第一条循环
    sql_part_data    varchar2(4000); -- 数据表_条件表达式
    sql_part_row     varchar2(4000); -- 行_维度数据表_条件表达式
    sql_part_col     varchar2(4000); -- 列_维度数据表_条件表达式
    err_msg          varchar2(100);  -- 错误信息
    bean_col_id      varchar2(4000); -- 列的排名bean:id列
    bean_col_name    varchar2(4000); -- 列的排名bean:name列
    bean_col_total   varchar2(4000); -- 列的排名bean:total列
    sql_row_order    varchar2(10);   -- 行_维度数据表_排序
    sql_col_order    varchar2(10);   -- 列_维度数据表_排序
    sql_total_rownum varchar2(100);  -- 合计行的行号是否加1
    col_index        number := -1;   -- 列_别名的编号
    TYPE RawCurTyp IS REF CURSOR;    -- 定义游标类型
    RS RawCurTyp; -- 定义游标
  begin
    -- 判断是否需要添加数据表,行维度表,列维度的sql语句中的条件表达式
    if (trim(data_sql_part) is null) then
      sql_part_data := '';
    else
      sql_part_data := ' where ' || data_sql_part;
    end if;
    if (trim(row_sql_part) is null) then
      sql_part_row := '';
    else
      sql_part_row := ' where ' || row_sql_part;
    end if;
    if (trim(col_sql_part) is null) then
      sql_part_col := '';
    else
      sql_part_col := ' where ' || col_sql_part;
    end if;
    -- 判断排序字符串
    if (trim(row_order) <> 'desc') then
      sql_row_order := ' asc';
    else
      sql_row_order := ' desc';
    end if;
    if (trim(col_order) <> 'desc') then
      sql_col_order := ' asc';
    else
      sql_col_order := ' desc';
    end if;
    -- 合计行的行号是否加1
    if (is_have_otheres = 'true') then
      sql_total_rownum := 'decode(row_id||row_name,''合计'',''合计'',rownum)';
    else
      sql_total_rownum := 'to_char(rownum)';
    end if;
    sql_col := 'select a.col_id, a.col_name, a.col_total from' || chr(10) ||
               '(select /*+ index(d col_id) */  grouping_id(s.col_id, s.col_name) type_id, s.col_id, decode( grouping_id(s.col_id, s.col_name),0,nvl2(s.col_id,s.col_name,''未知'')) col_name, sum(d.total_data) as col_total' ||
               chr(10) || '  from (select ' || data_time_id ||
               '    time_id, ' || data_dim_col || '  col_id, ' ||
               data_value || ' total_data from ' || data_table_name ||
               sql_part_data || ' ) d,' || chr(10) || '       (select ' ||
               col_id || ' col_id,' || col_name || ' col_name from ' ||
               col_table_name || sql_part_col || ') s' || chr(10) ||
               '  where d.col_id = s.col_id--(+)' || chr(10) ||
               '  and d.time_id >= ' || data_start_time || chr(10) ||
               '  and d.time_id <  ' || data_end_time || chr(10) ||
               '  group by grouping sets((),(s.col_id, s.col_name))' ||
               chr(10) || '  order by type_id desc, col_total ' ||
               sql_col_order || ') a' || chr(10) || 'where rownum <= ' ||
               (col_topn + 1);

    print(sql_col, '①查询列的排名');
    sql_isfirst := 'Y';
    open rs for to_char(sql_col);
    loop
      fetch rs
        into bean_col_id, bean_col_name, bean_col_total;
      exit when rs%notfound;
      col_index := col_index + 1;
      if (sql_isfirst = 'N') then
        begin
          -- 第一条不执行
          sql_p0 := sql_p0 || ',''' || bean_col_id || ''' "' ||
                    bean_col_name || '"';
          -- sql_p1 :=sql_p1 || 'to_char(decode(type_id,3,' ||bean_col_total|| ',"' || bean_col_id || '")) "' || bean_col_id || '",';
          sql_p1 := sql_p1 || 'to_char(decode(type_id,3,' || bean_col_total ||
                    ',"c' || col_index || '")) "c' || col_index || '",';
          -- sql_p2 :=sql_p2 || ',sum(decode(col_id,''' || bean_col_id || ''',col_data,null)) "' || bean_col_id || '"';
          sql_p2 := sql_p2 || ',sum(decode(col_id,''' || bean_col_id ||
                    ''',col_data,null)) "c' || col_index || '"';
          sql_p4 := sql_p4 || '''' || bean_col_id || ''',';
        end;
      else
        sql_isfirst := 'N';
      end if;
    end loop;
    close rs;
    sql_p3  := data_time_id || ' time_id,' || data_dim_row || ' row_id,' ||
               data_dim_col || ' col_id ,' || data_value ||
               ' col_data from ' || data_table_name || sql_part_data;
    sql_p5  := sql_p5 || data_time_id || ' time_id,' || data_dim_row ||
               ' row_id,' || data_value || ' data_value from ' ||
               data_table_name || sql_part_data;
    sql_p6  := sql_p6 || row_id || ' row_id,' || row_name ||
               ' row_name from ' || row_table_name || sql_part_row;
    str_sql := 'select ''0'' ROW_NUM,null "ROW_ID",null "ROW_NAME"' ||
               sql_p0 || ',null "合计" from dual union all' || chr(10) ||
               'select ' || sql_total_rownum ||
               ' row_num ,rd_table.* from (select r21.row_id,' || chr(10) ||
               'decode(type_id,3,''合计'',r21.row_name) row_name,' ||
               chr(10) || sql_p1 || chr(10) || ' r21.row_total  from' ||
               chr(10) || '(SELECT /*+ index(c11 col_id) */ row_id ' ||
               sql_p2 || chr(10) || 'FROM (select ' || sql_p3 || chr(10) ||
               ') c11' || chr(10) || 'WHERE time_id >=' || data_start_time ||
               '  AND time_id <' || data_end_time || chr(10) ||
               'and col_id in (' || sql_p4 || 'null)' ||
               '--and row_id in (1,2,3)' || chr(10) ||
               'GROUP BY row_id ) d21,' || chr(10) ||
               '(select type_id,row_id,row_name,row_total from (' ||
               chr(10) ||
               'select /*+ index(r11 row_id) */grouping_id(r12.row_id,r12.row_name) type_id,r12.row_id,r12.row_name,sum(data_value) as row_total' ||
               chr(10) || 'from (select ' || sql_p5 || chr(10) ||
               ') r11,(select ' || sql_p6 || ') r12' || chr(10) ||
               'where r11.row_id = r12.row_id(+)' || chr(10) ||
               'and r11.time_id >=' || data_start_time ||
               '  and r11.time_id <' || data_end_time || chr(10) ||
               'group by grouping sets ((),(r12.row_id,r12.row_name))' ||
               chr(10) || 'order by type_id desc,row_total ' ||
               sql_row_order || ') r3 where rownum <=' || (row_topn + 1) ||
               chr(10) || ') r21' || chr(10) ||
               'where r21.row_id = d21.row_id(+)' || chr(10) ||
               'order by r21.type_id,r21.row_total ' || sql_row_order ||
               ') rd_table';
    print(str_sql, '②查询列和行的数据');
    return str_sql;

  exception
    when no_data_found then
      print('错误(返回null):没有查到数据!');
      return '';
    when others then
      err_msg := substr(sqlerrm, 1, 100);
      print('错误(返回null):' || err_msg);
      return '';
  end get_crosstab;
end;
/
