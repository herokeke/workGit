CREATE package rpt is
  /*
  in        printclob 打印的字符串;
            printdesc 打印的提示信息前缀;
            isprint   是否打印:true打印;fase:不打印,默认打印;
  */
  procedure print(printclob clob,
                  printdesc varchar2 := '---------------',
                  isprint   varchar2 := 'true');
  /*
  in        str_sql 查询一个字段;
            compart 分隔符,默认为逗号【,】
  out       用制定的分隔符拼接该列字段返回一个字符串,例如【a,b,c】
  exception 如果sql语句不能执行,则返回空格
  */
  function get_column(str_sql varchar2, compart varchar2 := ',') return clob;
  /*
  in         13位毫秒值
  out       日期型
  exception 如果不能执行,则返回null
  */
  function get_datetime(millisecond number) return date;
  /*
  in         日期型
  out       13位毫秒值
  exception 如果不能执行,则返回null
  */
  function get_millisecond(datetime date) return number;
  /*
  in        field_name   字段名称;
            field_value  字段的值
            compart      分隔符,默认使用单引号【'】
      field_jion   字段拼接关键字,默认使用【and】
  out       用制定的分隔符拼接字段该列返回一个字符串,前后有空格,例如【and res_id in (a,b,c)】.
  exception 如果sql_field为null,则返回空格
  */
  function get_expression(field_name  varchar2,
                          field_value varchar2,
                          compart     varchar2 := '''',
                          field_jion  VARCHAR2 := 'and') return varchar2;

  function get_crosstab(data_table_name varchar2, -- 1  数据表_表名
                        data_time_id    varchar2, -- 2  数据表_时间列
                        data_value      varchar2, -- 3  数据表_数据列
                        data_start_time varchar2, -- 4  数据表_开始时间
                        data_end_time   varchar2, -- 5  数据表_结束时间
                        data_dim_row    varchar2, -- 6  数据表_行维度(注意和行维度对应,参数8)
                        data_dim_col    varchar2, -- 7  数据表_列维度(注意和列维度对应,参数11)
                        row_table_name  varchar2, -- 8  行_维度数据表_表名(注意和行维度对应,参数6)
                        row_id          varchar2, -- 9  行_维度数据表_ID列
                        row_name        varchar2, -- 10 行_维度数据表_名称列
                        col_table_name  varchar2, -- 11 列_维度数据表_表名(注意和行维度对应,参数7)
                        col_id          varchar2, -- 12 列_维度数据表_ID列
                        col_name        varchar2, -- 13 列_维度数据表_名称列
                        row_topn        numeric := 10,  -- 14 行_topN
                        col_topn        numeric := 10,  -- 15 列_topN
                        data_sql_part   varchar2 := '', -- 16 数据表_条件表达式
                        row_sql_part    varchar2 := '', -- 17 行_维度数据表_条件表达式
                        col_sql_part    varchar2 := '', -- 18 列_维度数据表_条件表达式
                        row_order       varchar2 := 'desc', -- 19 行_维度数据表_排序
                        col_order       varchar2 := 'desc', -- 20 列_维度数据表_排序
                        is_have_otheres varchar2 := 'false' -- 21 合计行的行号是否换成'合计'
                        ) return clob; -- 返回的交叉表(两个维度)的sql语句,适用于星形结构的数据表
end;
/
