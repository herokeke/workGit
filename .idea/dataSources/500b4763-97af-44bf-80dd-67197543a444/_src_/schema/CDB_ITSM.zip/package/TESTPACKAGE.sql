CREATE package testpackage as type test_cursor is ref cursor
end testpackage;
/
